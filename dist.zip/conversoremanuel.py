import tkinter as tk
from tkinter import filedialog, messagebox
import re
import json

# Categorias pré-definidas
CATEGORIES = {
    "all": "ALL",
    "a_grande_conquista": "A GRANDE CONQUISTA",
    "4k": "4K",
    "globo": "GLOBO",
    "sbt": "SBT",
    "record_tv": "RECORD TV",
    "abertos": "ABERTOS",
    "discovery": "DISCOVERY",
    "documentarios": "DOCUMENTÁRIOS",
    "jornalismo": "JORNALISMO",
    "religioso": "RELIGIOSO",
    "variedades": "VARIEDADES",
    "hbo": "HBO",
    "telecine": "TELECINE",
    "cine_sky": "CINE SKY",
    "filmes_e_series": "FILMES E SERIES",
    "esportes": "ESPORTES",
    "sportv": "SPORTV",
    "premiere": "PREMIERE",
    "nosso_futebol": "NOSSO FUTEBOL",
    "xxx_adultos": "XXX ADULTOS",
    "infantil": "INFANTIL"
}

# Palavras-chave para categorias específicas
CATEGORY_KEYWORDS = {
    "filmes_e_series": ["AXN", "TNT", "CINEMAX", "STUDIO", "SYFY", "FX", "MEGAPIX", "SPACE", "TNT", "TNT SERIES", "TNT NOVELAS", "A&E", "AMC", "COMEDY CENTRAL", "PARAMOUNT", "UNIVERSAL", "WARNER"]
}

def categorize_channel(name):
    for category, keywords in CATEGORY_KEYWORDS.items():
        for keyword in keywords:
            if keyword in name.upper():
                return category
    return None

def parse_m3u(file_path):
    categories = {}

    with open(file_path, 'r', encoding='utf-8') as f:
        for line in f:
            line = line.strip()
            if line.startswith('#EXTINF:'):
                match = re.match(r'#EXTINF:-1 tvg-id="([^"]*)" tvg-name="([^"]*)" tvg-logo="([^"]*)".*,(.*)', line)
                if match:
                    tvg_id, tvg_name, logo_url, name = match.groups()
                    url = next(f).strip()
                    group_match = re.search(r'#EXTGRP:([^,]+)', line)
                    if group_match:
                        category = group_match.group(1).lower()  # Converta para minúsculas para garantir consistência
                        if category in CATEGORIES:
                            category = CATEGORIES[category]  # Use a categoria pré-definida, se disponível
                    else:
                        category = name.lower()  # Use o nome do canal como categoria se não houver categoria definida
                    if any(original_content in name.lower() for original_content in CATEGORIES.keys()):
                        category = name.split()[0].upper()  # Use a primeira palavra do nome do canal como categoria
                    else:
                        category = categorize_channel(name) or category
                    if category not in categories:
                        categories[category] = []
                    categories[category].append({"name": name, "url": url, "logoUrl": logo_url, "tvgName": tvg_name, "category": category})

    return {"categories": categories}

def generate_json(m3u_file_path, json_output_path, root):
    parsed_data = parse_m3u(m3u_file_path)
    # Adicionando a informação do desenvolvedor
    parsed_data["Developer"] = "Emanuel Nascimento"
    with open(json_output_path, 'w', encoding='utf-8') as f:
        json.dump(parsed_data, f, indent=4)
    messagebox.showinfo("Sucesso", "JSON gerado com sucesso!")
    root.destroy()

def select_m3u_file():
    file_path = filedialog.askopenfilename(filetypes=[("M3U files", "*.m3u"), ("All files", "*.*")])
    if file_path:
        m3u_entry.delete(0, tk.END)
        m3u_entry.insert(0, file_path)

def select_output_file():
    file_path = filedialog.asksaveasfilename(defaultextension=".json", filetypes=[("JSON files", "*.json"), ("All files", "*.*")])
    if file_path:
        output_entry.delete(0, tk.END)
        output_entry.insert(0, file_path)

def convert_file():
    m3u_file_path = m3u_entry.get()
    json_output_path = output_entry.get()
    if m3u_file_path and json_output_path:
        generate_json(m3u_file_path, json_output_path, root)
    else:
        messagebox.showwarning("Aviso", "Por favor, selecione ambos os arquivos!")

# Interface gráfica usando tkinter
root = tk.Tk()
root.title("Conversor de M3U para JSON")
root.configure(bg="#121212")  # Cor de fundo do contêiner

frame = tk.Frame(root, padx=10, pady=10, bg="#121212")  # Cor de fundo do contêiner interno
frame.pack(padx=10, pady=10)

m3u_label = tk.Label(frame, text="Selecione o arquivo M3U:", bg="#121212", fg="white")  # Cores do texto
m3u_label.grid(row=0, column=0, sticky="w")

m3u_entry = tk.Entry(frame, width=50, bg="#212121", fg="white")  # Cores do fundo e texto da entrada
m3u_entry.grid(row=0, column=1, padx=(0, 10), pady=10)

m3u_button = tk.Button(frame, text="Selecionar", command=select_m3u_file, bg="#009688", fg="white")  # Cores do botão
m3u_button.grid(row=0, column=2, pady=10, padx=(0, 10))

output_label = tk.Label(frame, text="Selecione o local de saída:", bg="#121212", fg="white")  # Cores do texto
output_label.grid(row=1, column=0, sticky="w")

output_entry = tk.Entry(frame, width=50, bg="#212121", fg="white")  # Cores do fundo e texto da entrada
output_entry.grid(row=1, column=1, padx=(0, 10), pady=10)

output_button = tk.Button(frame, text="Selecionar", command=select_output_file, bg="#009688", fg="white")  # Cores do botão
output_button.grid(row=1, column=2, pady=10, padx=(0,10))

convert_button = tk.Button(frame, text="Converter", command=convert_file, bg="#FF5722", fg="white")  # Cores do botão
convert_button.grid(row=2, columnspan=3, pady=10)

# Adicionando a informação do desenvolvedor ao rodapé
developer_label = tk.Label(root, text="Developer: Emanuel Nascimento", bg="#121212", fg="white")
developer_label.pack(side="bottom", padx=10, pady=(0, 5), anchor="e")

root.mainloop()
